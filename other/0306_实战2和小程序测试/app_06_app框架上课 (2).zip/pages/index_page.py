#!/usr/bin/env python3
#-*- coding:utf-8 -*-
# email: wagyu2016@163.com
# wechat: shoubian01
# author: 王雨泽
from common.basepage import BasePage


class NavPage(BasePage):
    """导航栏。
    属于多个页面。
    """
    # 元素定位器



    # 方法